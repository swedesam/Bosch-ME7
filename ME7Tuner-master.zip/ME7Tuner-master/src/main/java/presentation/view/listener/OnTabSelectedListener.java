package presentation.view.listener;

public interface OnTabSelectedListener {
    void onTabSelected(boolean selected);
}
