package data.contract;

public class MlhfmFileContract {
    public static final String MAF_VOLTAGE_HEADER = "voltage";
    public static final String KILOGRAM_PER_HOUR_HEADER = "kg/hr";
}
