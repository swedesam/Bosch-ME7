# Release

* Use Maven package plugin to build JAR with dependencies